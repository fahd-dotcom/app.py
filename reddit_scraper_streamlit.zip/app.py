# app.py
print("Hello from Streamlit placeholder")